
;(function($){
    "use strict";
    var tabContent,
        checkParaScroll,
        smoothScrollActive;

    $(function(){
       tabContent();
    });

    
    checkParaScroll = function() {
        // active if have search in URL
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const parentCat = urlParams.get('parent');
        const childCat = urlParams.get('child');

        // scroll to tab
        if(urlParams.has('parent')) {
            const parentCat = urlParams.get('parent');
            var parentCatID = '#' + parentCat;
            
            $('html, body').animate({
                scrollTop: $(parentCatID).offset().top - 120,
            },500,'linear')
        }

        // actived tab content
        if(urlParams.has('parent')) {
            const parentCat = urlParams.get('parent');
            $myTabs.find('ul.tabs li').removeClass('current');
            $myTabs.find('.tab-content').removeClass('current');
           
            $("#" + parentCat).addClass('current');
            console.log("#tab-" + parentCat);
            $("#tab-" + parentCat).addClass('current');
        }
    },

    smoothScrollActive = function(){
        // smoothScroll and active
        $('a[href*="#"]').on('click', function (e) {
            e.preventDefault();
            var href_anchor = $(this).attr('href');
            $myTabs.find('ul.tabs li').removeClass('current');
            $myTabs.find('.tab-content').removeClass('current');

            var targetID = href_anchor.replace("#","");
            $(href_anchor).addClass('current');
            $(".tab-content-"+ targetID).addClass('current');
        }); 
    }

    tabContent = function(){
        // active if have search in URL
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
       

        // use multi tab js
        $(".dl-tabs").each(function() {
            var $myTabs = $(this);
            // default

            // actived tab content
            if(urlParams.has('parent')) {
                const parentCat = urlParams.get('parent');
                $myTabs.find('ul.tabs li').removeClass('current');
                $myTabs.find('.tab-content').removeClass('current');
                
                $("#" + parentCat).addClass('current');
                $("#tab-" + parentCat).addClass('current');
            }

            $myTabs.find('ul.tabs li').click(function() {
                //default
                var $this = $(this),
                    tab_id = $this.attr('data-tab');
        
                $myTabs.find('ul.tabs li').removeClass('current');
                $myTabs.find('.tab-content').removeClass('current');
        
                $this.addClass('current');
                $("#"+ tab_id).addClass('current');
                
                // reset slick slider
                var $teamPostSlider = $('.teams .post-slider'),
                    $locationPostSlider = $('.location .post-slider'),
                    $mapSlider = $('.slider-for');
                
                if($teamPostSlider.length!=0) {
                    $teamPostSlider.slick("setPosition", 0);
                    $teamPostSlider.slick('refresh');
                }
                if($locationPostSlider.length!=0) {
                    $locationPostSlider.slick("setPosition", 0);
                    $locationPostSlider.slick('slickGoTo', 0);
                }
                if($mapSlider.length!=0) {
                    $mapSlider.slick("setPosition", 0);
                    $mapSlider.slick('slickGoTo', 0);
                }
                
            })
        });
    }
})(jQuery);