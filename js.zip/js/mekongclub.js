
;(function($){
    "use strict";
    var smoothLink,
        targetLink,
        disScrollElementor;

    $(function(){
       smoothLink();
       targetLink();
       // disScrollElementor();
    });

    // Disable Smooth Scroll in Elementor
    disScrollElementor = function() {
        var change_elementor_options = function() {
            if ( typeof elementorFrontend === 'undefined' ) {
                return;
            }
            elementorFrontend.on( 'components:init', function() {
                elementorFrontend.utils.anchors.setSettings( 'selectors.targets', '.dummy-selector' );
            } );
        };
        $( window ).on( 'elementor/frontend/init', change_elementor_options );
    }
    targetLink = function() {
        // active if have search in URL
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        // scroll to tab
        if(urlParams.has('target')) {
            var target = urlParams.get('target');
            var targetID = '#' + target;
            if(target == 'become-a-volunteer') {
                $('html, body').animate({
                    scrollTop: $(targetID).offset().top - 250
                },500,'linear')
            } else {
                $('html, body').animate({
                    scrollTop: $(targetID).offset().top - 120
                },500,'linear')
            }
            
        }
    }
    smoothLink = function() {
        $('a[href*="#"]').on('click', function (e) {
            var popup_action_name = $(this).attr('name');
            if(popup_action_name != 'no-scrolling') {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: $($(this).attr('href')).offset().top - 120,
                },500,'linear')
            }
        });
    }
})(jQuery);