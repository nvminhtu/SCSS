
;(function($){
    "use strict";
    var accordion;

    $(function(){
       accordion();
    });

    accordion = function() {
        $(".accordion_head").click(function () {
            if ($('.accordion_body').is(':visible')) {
                $(".accordion_body").slideUp(300);
                $(".expand").removeClass('minus');
            }
            if ($(this).next(".accordion_body").is(':visible')) {
                $(this).next(".accordion_body").slideUp(300);
                $(this).children(".expand").removeClass('minus');
            } else {
                $(this).next(".accordion_body").slideDown(300);
                $(this).children(".expand").addClass('minus');
            }
        });
    }
})(jQuery);